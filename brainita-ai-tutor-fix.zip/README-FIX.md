# Brainita AI Tutor targeted fix package

These files are replacements for the current Lovable/GitHub project at commit:
`2b8768021a6bd15df4881abce48934b122da9b7a`

Replace these paths in the repository:

- `src/components/AppShell.tsx`
- `src/routes/onboarding.tsx`
- `src/routes/__root.tsx`
- `src/routes/profile.tsx` (new)

What this fixes:
1. Adds the missing `/profile` route.
2. Makes `studentName` and onboarding `hint` compatible with `exactOptionalPropertyTypes`.
3. Loads Inter + Space Grotesk.
4. Mounts the existing Sonner `<Toaster />`.

Note: TanStack Router should regenerate `src/routeTree.gen.ts` during dev/build after the new file route is added.
